/**
 * For storing models (forms) that are shared between the HCP and patient.
 * 
 * @author Kai Presler-Marshall
 */
package edu.ncsu.csc.itrust2.forms.hcp_patient;
