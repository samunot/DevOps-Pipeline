/**
 * Package for controllers that should be shared between multiple types of
 * iTrust2 personnel.
 * 
 * @author Kai Presler-Marshall
 */
package edu.ncsu.csc.itrust2.controllers.personnel;
