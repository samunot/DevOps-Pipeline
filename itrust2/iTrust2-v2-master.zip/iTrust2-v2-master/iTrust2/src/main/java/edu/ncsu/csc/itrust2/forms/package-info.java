/**
 * All of the Forms for the Web Layer of iTrust2.
 *
 * @author Kai Presler-Marshall
 *
 */
package edu.ncsu.csc.itrust2.forms;
